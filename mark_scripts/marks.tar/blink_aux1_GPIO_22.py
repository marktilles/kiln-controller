#!/usr/bin/env python
import time

from gpiozero import Button, LEDBoard
from signal import pause
import warnings, os, sys
service_running_ledGPIO = 22
service_running_led=LEDBoard(service_running_ledGPIO)
service_running_led.blink(on_time=1, off_time=1)

print "Blinking GPIO 22 ... for 24 hours or the next reboot."
time.sleep (86400)

